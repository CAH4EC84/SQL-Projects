﻿#https://postgrespro.ru/docs/postgrespro/12/app-psql
Set-Location 'Z:\PostgreSQL\12\bin\';
$env:PGPASSWORD = 'Hf,jnfVtlkfqy2020';
.\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -f Z:\XmlImport\Sripts\test\RecsCountWIN1251.sql  --csv --output=Z:\XmlImport\Sripts\test\RecsCountWIN1251_before.log
.\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -f Z:\XmlImport\Sripts\test\InsertTMPWin1251.sql  --csv --output=Z:\XmlImport\Sripts\test\InsertTMPWin1251.log
.\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -f Z:\XmlImport\Sripts\test\RecsCountWIN1251.sql  --csv --output=Z:\XmlImport\Sripts\test\RecsCountWIN1251_after.log
