﻿Move-Item  -Path z:\XmlImport\DailyData\*  -Destination Z:\PostgreSQL\12\data\XmlImport\ #importDir

#Заливаем данные через консоль PostgreSQL

Set-Location 'Z:\PostgreSQL\12\bin\';
$env:PGPASSWORD = 'Hf,jnfVtlkfqy2020';
$results = .\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -a -f Z:\XmlImport\Sripts\RecsCount.sql 
.\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -f Z:\XmlImport\Sripts\ImportXMLFiles.sql 
$results += .\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -a -f Z:\XmlImport\Sripts\RecsCount.sql 


#Переносим в архив.
Move-Item  -Path Z:\PostgreSQL\12\data\XmlImport\*  -Destination Z:\XmlImport\Arc\ #arcDir
$results








