﻿#Переносим в каталог для импорта
Move-Item  -Path z:\XmlImport\DailyData\*  -Destination Z:\PostgreSQL\12\data\XmlImport\ #importDir

#Заливаем данные через консоль PostgreSQL
Set-Location 'Z:\PostgreSQL\12\bin\';
$env:PGPASSWORD = 'Hf,jnfVtlkfqy2020';
.\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -f Z:\XmlImport\Sripts\RecsCount.sql --csv --output=Z:\XmlImport\Sripts\RecsCountBefore.log
.\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -f Z:\XmlImport\Sripts\ImportXMLFiles.sql 
.\psql --% -h localhost -d Medis_Reports -U postgres -p 5432 -f Z:\XmlImport\Sripts\RecsCount.sql  --csv --output=Z:\XmlImport\Sripts\RecsCountAfter.log


#Переносим в архив.
Move-Item  -Path Z:\PostgreSQL\12\data\XmlImport\*  -Destination Z:\XmlImport\Arc\ #arcDir









